/*
Navicat MySQL Data Transfer

Source Server         : 3306MySQL8
Source Server Version : 80012
Source Host           : localhost:3306
Source Database       : xmall

Target Server Type    : MYSQL
Target Server Version : 80012
File Encoding         : 65001

Date: 2023-11-07 13:11:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `link_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系人',
  `link_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系地址',
  `link_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系电话',
  `user_id` bigint(20) DEFAULT NULL COMMENT '所属用户',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='收货地址';

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES ('1', '哈喽', '北京市前门大街120号', '13909768928', '21');
INSERT INTO `address` VALUES ('3', '夹克', '合肥', '13099887799', '22');
INSERT INTO `address` VALUES ('4', '哈哈哈', '南京', '13988776655', '21');
INSERT INTO `address` VALUES ('5', '张三', '蓝星', '18736688211', '1');
INSERT INTO `address` VALUES ('6', 'wang', '蓝星', '18736688211', '24');
INSERT INTO `address` VALUES ('7', 'rr', '浙江温州', '18394532334', '11');

-- ----------------------------
-- Table structure for banner
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片地址',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '关联url',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='轮播图';

-- ----------------------------
-- Records of banner
-- ----------------------------
INSERT INTO `banner` VALUES ('2', 'http://localhost:9999/files/1699153363414', 'http://localhost:8001/front/goods?id=1');
INSERT INTO `banner` VALUES ('3', 'http://localhost:9999/files/1699152114695', 'http://localhost:8001/front/goods?id=22');

-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `goods_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户id',
  `count` int(11) DEFAULT NULL COMMENT '商品数量',
  `create_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加入时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `goods_user` (`goods_id`,`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='购物车';

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO `cart` VALUES ('4', '22', '22', '3', '2022-02-16 21:03:53');
INSERT INTO `cart` VALUES ('5', '1', '21', '1', '2022-03-04 22:08:00');
INSERT INTO `cart` VALUES ('6', '19', '11', '1', '2022-03-04 22:08:27');
INSERT INTO `cart` VALUES ('8', '19', '23', '1', '2022-11-13 22:50:08');
INSERT INTO `cart` VALUES ('11', '18', '23', '1', '2022-11-14 23:36:04');
INSERT INTO `cart` VALUES ('12', '19', '24', '1', '2022-11-15 00:00:48');
INSERT INTO `cart` VALUES ('13', '18', '3', '1', '2023-11-04 21:06:06');
INSERT INTO `cart` VALUES ('14', '1', '11', '1', '2023-11-05 09:12:27');
INSERT INTO `cart` VALUES ('15', '21', '11', '1', '2023-11-05 10:58:54');
INSERT INTO `cart` VALUES ('16', '22', '11', '1', '2023-11-06 10:10:52');
INSERT INTO `cart` VALUES ('17', '16', '11', '1', '2023-11-06 10:39:58');

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类名称',
  `no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类编号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品分类';

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '文化美食', '1001');
INSERT INTO `category` VALUES ('2', '文化创意', '1002');
INSERT INTO `category` VALUES ('3', '文化非遗', '1003');
INSERT INTO `category` VALUES ('4', '文化传媒', '1004');
INSERT INTO `category` VALUES ('5', '文化休闲娱乐', '1005');

-- ----------------------------
-- Table structure for collect
-- ----------------------------
DROP TABLE IF EXISTS `collect`;
CREATE TABLE `collect` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `goods_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `goods_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品图片',
  `goods_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品id',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户id',
  `create_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收藏时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='收藏表';

-- ----------------------------
-- Records of collect
-- ----------------------------
INSERT INTO `collect` VALUES ('6', 'JÄMLIK 洋黎 香味烛和玻璃杯', 'http://localhost:9999/files/1668350640133', '18', '24', '2022-11-14 23:32:05');
INSERT INTO `collect` VALUES ('9', '南京特产正宗桂花风味盐水鸭盐水鸡烧鸡酱香香辣酱板鸭腿肉类零食 ', 'http://localhost:9999/files/1699152547379', '1', '11', '2023-11-06 10:12:51');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品描述',
  `no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品编号',
  `price` decimal(10,2) DEFAULT NULL COMMENT '原价',
  `discount` double(10,2) DEFAULT NULL COMMENT '折扣',
  `store` int(11) DEFAULT NULL COMMENT '库存',
  `praise` int(11) DEFAULT '0' COMMENT '点赞数',
  `sales` int(11) DEFAULT '0' COMMENT '销量',
  `category_id` bigint(20) DEFAULT NULL COMMENT '分类id',
  `imgs` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品图片',
  `create_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建时间',
  `recommend` tinyint(1) DEFAULT NULL COMMENT '是否推荐：0不推荐，1推荐',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建用户id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品';

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('1', '南京特产正宗桂花风味盐水鸭盐水鸡烧鸡酱香香辣酱板鸭腿肉类零食 ', '南京特产正宗桂花风味盐水鸭盐水鸡烧鸡酱香香辣酱板鸭腿肉类零食 掌柜推荐￥19.8起', 'g1001', '19.80', '0.95', '6', '6', '5', '1', '[\"http://localhost:9999/files/1699152547379\"]', '2023-11-05 22:29:15', '1', '22');
INSERT INTO `goods` VALUES ('16', '买一送一南京特产盐水鸭正宗酱香香辣风干酱板鸭酱鸭肉类零食', '买一送一南京特产盐水鸭正宗酱香香辣风干酱板鸭酱鸭肉类零食 推荐￥39.8起', 'g1002', '39.80', '0.70', '2', '1', '1', '1', '[\"http://localhost:9999/files/1699152605518\"]', '2023-11-05 22:29:15', '1', '22');
INSERT INTO `goods` VALUES ('17', '南京特产熟食盐水鸭礼盒桂花风味樱桃谷真空装即食卤味特色美食 ', '南京特产熟食盐水鸭礼盒桂花风味樱桃谷真空装即食卤味特色美食 掌柜推荐¥26.9起', 'g1003', '26.90', '0.80', '10', '0', '0', '1', '[\"http://localhost:9999/files/1699152652284\"]', '2023-11-05  22:31:15', '1', '22');
INSERT INTO `goods` VALUES ('18', 'JÄMLIK 洋黎 香味烛和玻璃杯', '装饰\n功能和细节\n秋季\n休闲放松', 'c1001', '29.00', '0.90', '29', '3', '1', '2', '[\"http://localhost:9999/files/1668350640133\",\"http://localhost:9999/files/1668350644279\"]', '2023-11-05 22:44:13', '1', '23');
INSERT INTO `goods` VALUES ('19', '南京特产茉莉鲜花饼中式糕点特色点心', '好一朵茉莉花南京特产茉莉鲜花饼中式糕点特色点心伴手礼宁饼礼盒 价格￥24.8', 'z1001', '32.00', '0.90', '11', '1', '1', '1', '[\"http://localhost:9999/files/1699153193406\"]', '2023-11-05  22:49:02', '1', '22');
INSERT INTO `goods` VALUES ('20', '雨花石金箔金陵三宝特色工艺品摆件', '南京云锦研究所旗舰店官方正品雨花石金箔金陵三宝特色工艺品摆件 ￥780起', 'c1001', '780.00', '0.90', '3', '0', '0', '3', '[\"http://localhost:9999/files/1699152809232\"]', '2023-11-06 22:05:49', '1', '23');
INSERT INTO `goods` VALUES ('21', '古典团扇中国风金属文创礼品', '南京书签特色旅游总统府古典团扇中国风金属文创礼品伴读随手礼 ￥13.8起', null, '25.00', '0.90', '33', '0', '1', '5', '[\"http://localhost:9999/files/1699152879645\"]', '2023-11-05 10:54:41', null, '1');
INSERT INTO `goods` VALUES ('22', '南京鸭血粉丝汤特产正宗老鸭粉米线', '南京鸭血粉丝汤特产正宗老鸭粉米线', null, '15.00', '0.80', '54', '0', '0', '1', '[\"http://localhost:9999/files/1699153479208\"]', '2023-11-05 11:04:41', '1', '1');
INSERT INTO `goods` VALUES ('23', '南京云锦手工蝴蝶胸针真金刺绣高档珍珠', '南京云锦手工蝴蝶胸针真金刺绣高档珍珠中国风特色礼品 ￥508起', null, '678.00', '0.70', '30', '0', '0', '4', '[\"http://localhost:9999/files/1699153725841\"]', '2023-11-05 11:08:47', '1', '1');
INSERT INTO `goods` VALUES ('24', '【南京】林俊杰南京演唱会', '【南京】林俊杰南京演唱会门票JJ20世界巡回演唱会门票 ￥1800起', null, '3000.00', '0.70', '200', '0', '0', '4', '[\"http://localhost:9999/files/1699153781744\"]', '2023-11-05 11:09:42', '1', '1');

-- ----------------------------
-- Table structure for order_goods
-- ----------------------------
DROP TABLE IF EXISTS `order_goods`;
CREATE TABLE `order_goods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单id',
  `goods_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `count` int(11) DEFAULT NULL COMMENT '数量',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='订单商品关系表';

-- ----------------------------
-- Records of order_goods
-- ----------------------------
INSERT INTO `order_goods` VALUES ('1', '1', '1', '4');
INSERT INTO `order_goods` VALUES ('2', '1', '3', '2');
INSERT INTO `order_goods` VALUES ('3', '2', '1', '4');
INSERT INTO `order_goods` VALUES ('4', '2', '3', '2');
INSERT INTO `order_goods` VALUES ('5', '4', '2', '5');
INSERT INTO `order_goods` VALUES ('6', '5', '1', '1');
INSERT INTO `order_goods` VALUES ('7', '6', '2', '1');
INSERT INTO `order_goods` VALUES ('8', '7', '4', '4');
INSERT INTO `order_goods` VALUES ('9', '7', '5', '2');
INSERT INTO `order_goods` VALUES ('10', '8', '2', '2');
INSERT INTO `order_goods` VALUES ('11', '8', '3', '2');
INSERT INTO `order_goods` VALUES ('12', '8', '4', '1');
INSERT INTO `order_goods` VALUES ('13', '9', '1', '1');
INSERT INTO `order_goods` VALUES ('14', '10', '3', '1');
INSERT INTO `order_goods` VALUES ('15', '10', '7', '1');
INSERT INTO `order_goods` VALUES ('16', '11', '1', '1');
INSERT INTO `order_goods` VALUES ('17', '12', '18', '1');
INSERT INTO `order_goods` VALUES ('18', '12', '19', '1');
INSERT INTO `order_goods` VALUES ('19', '13', '1', '1');
INSERT INTO `order_goods` VALUES ('20', '14', '21', '1');
INSERT INTO `order_goods` VALUES ('21', '15', '1', '1');
INSERT INTO `order_goods` VALUES ('22', '16', '16', '1');

-- ----------------------------
-- Table structure for t_message
-- ----------------------------
DROP TABLE IF EXISTS `t_message`;
CREATE TABLE `t_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '内容',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '评论人',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '评论时间',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父ID',
  `foreign_id` bigint(20) DEFAULT '0' COMMENT '关联id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='留言表';

-- ----------------------------
-- Records of t_message
-- ----------------------------
INSERT INTO `t_message` VALUES ('20', '哈哈哈', 'admin', '2021-05-22 10:48:55', null, '1');
INSERT INTO `t_message` VALUES ('21', '哦豁', 'admin', '2021-05-22 10:49:48', null, '1');
INSERT INTO `t_message` VALUES ('23', '哈哈哈', 'hello', '2021-05-24 17:13:45', '22', '1');
INSERT INTO `t_message` VALUES ('24', '家人很满意', 'hello', '2021-05-24 17:13:58', null, '1');
INSERT INTO `t_message` VALUES ('25', '好', 'hello', '2021-06-06 12:41:30', null, '16');
INSERT INTO `t_message` VALUES ('26', '非常好', 'hello', '2021-06-06 22:32:45', null, '17');
INSERT INTO `t_message` VALUES ('27', '还不错', 'admin', '2022-11-13 13:35:24', null, '1');
INSERT INTO `t_message` VALUES ('28', '很有氛围', 'wang', '2022-11-14 23:35:08', null, '18');
INSERT INTO `t_message` VALUES ('29', 'nice！！！', 'wang', '2022-11-14 23:35:16', null, '19');
INSERT INTO `t_message` VALUES ('31', '还可以', 'tom', '2023-11-05 11:28:18', null, '21');

-- ----------------------------
-- Table structure for t_notice
-- ----------------------------
DROP TABLE IF EXISTS `t_notice`;
CREATE TABLE `t_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_notice
-- ----------------------------
INSERT INTO `t_notice` VALUES ('2', '平台于2023年11月11日进行第二次更新，届时停机维护', '更新至1.0，平台于2023年1月1日进行第二次更新，届时停机维护', '2023-11-04 17:13:46');

-- ----------------------------
-- Table structure for t_order
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `order_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单编号',
  `total_price` decimal(10,2) DEFAULT NULL COMMENT '总价',
  `user_id` bigint(20) DEFAULT NULL COMMENT '下单人id',
  `link_user` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系人',
  `link_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系电话',
  `link_address` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '送货地址',
  `state` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '待付款' COMMENT '状态',
  `create_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建时间',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建用户id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='订单表';

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('1', '20210602115530120326', '4399.00', '21', '张三', '13909768928', '北京市前门大街120号', '待收货', '2021-06-02 11:55:30', '22');
INSERT INTO `t_order` VALUES ('12', '20221114233308061804', '725.10', '24', 'wang', '18736688211', '蓝星', '已完成', '2022-11-14 23:33:08', null);
INSERT INTO `t_order` VALUES ('15', '20231105144810337787', '18.81', '11', 'rr', '18394532334', '浙江温州', '待发货', '2023-11-05 14:48:10', null);
INSERT INTO `t_order` VALUES ('16', '20231106101136620762', '27.86', '11', 'rr', '18394532334', '浙江温州', '待发货', '2023-11-06 10:11:36', null);

-- ----------------------------
-- Table structure for t_permission
-- ----------------------------
DROP TABLE IF EXISTS `t_permission`;
CREATE TABLE `t_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `path` varchar(255) DEFAULT NULL COMMENT '菜单路径',
  `icon` varchar(255) DEFAULT 's-data' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限菜单表';

-- ----------------------------
-- Records of t_permission
-- ----------------------------
INSERT INTO `t_permission` VALUES ('1', '首页', '首页', '/home', 's-home');
INSERT INTO `t_permission` VALUES ('2', '用户管理', '用户管理', '/user', 'user-solid');
INSERT INTO `t_permission` VALUES ('3', '角色管理', '角色管理', '/role', 's-cooperation');
INSERT INTO `t_permission` VALUES ('4', '菜单管理', '菜单管理', '/permission', 'menu');
INSERT INTO `t_permission` VALUES ('5', '公告管理', '公告管理', '/notice', 'data-board');
INSERT INTO `t_permission` VALUES ('8', '轮播图管理', '轮播图管理', '/banner', 'picture');
INSERT INTO `t_permission` VALUES ('9', '商品分类管理', '商品分类管理', '/category', 'tickets');
INSERT INTO `t_permission` VALUES ('11', '商品管理', '商品管理', '/goods', 's-goods');
INSERT INTO `t_permission` VALUES ('12', '订单管理', '订单管理', '/order', 's-data');
INSERT INTO `t_permission` VALUES ('13', '收货地址管理', '收货地址管理', '/address', 's-data');

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `permission` varchar(2000) DEFAULT NULL COMMENT '权限列表',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='角色表';

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('1', '超级管理员', '所有权限', '[1,2,3,4,5,8,9,11,12,13]');
INSERT INTO `t_role` VALUES ('2', '普通用户', '部分权限', '[8,1,13]');
INSERT INTO `t_role` VALUES ('3', '商家', null, '[1,12,13]');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `nick_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `age` int(11) DEFAULT NULL COMMENT '年龄',
  `account` decimal(10,2) DEFAULT '0.00' COMMENT '账户余额',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `username` (`username`,`nick_name`,`email`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户表';

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'admin', 'admin', '管理员', '111124444', '13978786565', '1622102316280', '[1]', '北京', null, '68.50');
INSERT INTO `t_user` VALUES ('11', 'tom', '123456', '汤姆', 'tom@qq.com', '13685249632', '1699144985342', '[2]', '上海', '22', '26228.68');
INSERT INTO `t_user` VALUES ('22', 'jack', '123456', '杰克', 'jack@qq.com', '13878549623', null, '[3]', '合肥', '30', '0.00');
INSERT INTO `t_user` VALUES ('23', 'jerry', '123456', '杰瑞', 'jerry@163.com', '13696965656', '1699237459562', '[3]', '北京', '21', '0.00');
