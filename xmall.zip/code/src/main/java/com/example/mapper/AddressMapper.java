package com.example.mapper;

import com.example.entity.Address;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface AddressMapper extends BaseMapper<Address> {

}
