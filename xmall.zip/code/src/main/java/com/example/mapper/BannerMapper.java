package com.example.mapper;

import com.example.entity.Banner;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface BannerMapper extends BaseMapper<Banner> {

}
