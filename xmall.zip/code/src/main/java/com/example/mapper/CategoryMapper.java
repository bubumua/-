package com.example.mapper;

import com.example.entity.Category;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface CategoryMapper extends BaseMapper<Category> {

}
