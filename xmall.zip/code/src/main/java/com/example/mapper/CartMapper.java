package com.example.mapper;

import com.example.entity.Cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface CartMapper extends BaseMapper<Cart> {

}
