package com.example.mapper;

import com.example.entity.Collect;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface CollectMapper extends BaseMapper<Collect> {

}
