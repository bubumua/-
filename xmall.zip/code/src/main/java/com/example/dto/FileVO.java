package com.example.dto;

import lombok.Data;

@Data
public class FileVO {
    private String url;
    private String name;
}
