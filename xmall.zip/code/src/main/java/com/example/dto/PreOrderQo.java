package com.example.dto;

import lombok.Data;

@Data
public class PreOrderQo {
    private String carts;
}
